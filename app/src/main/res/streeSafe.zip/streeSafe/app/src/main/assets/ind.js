document.addEventListener('DOMContentLoaded', function() {
    // Show a welcome message when the page loads
    alert("Welcome to the StreeSafe App. Use the features to stay safe.");
    }

    // Get the button element
